package Controller;
import Model.Appointments;
import Model.Customer;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableView;

public class ViewAppointmentController {

    @FXML
    private TableView<Customer> customerTableView;

    @FXML
    private TableView<Appointments> appointmentTableView;

    @FXML
    private Button deleteCustomerButton;

    @FXML
    private Button editCustomerButton;

    @FXML
    private Button addCustomerButton;

    @FXML
    private Button addAppointmentButton;

    @FXML
    private Button deleteAppointmentButton;

    @FXML
    private Button editAppointmentButton;

    @FXML
    private RadioButton currentWeekRadioButton;

    @FXML
    private RadioButton currentMonthRadioButton;

    @FXML
    private RadioButton allRadioButton;

    @FXML
    private Button goToReportsButton;

    @FXML
    private void OnDeleteCustomerButtonClicked() {
        // TODO: implement method
    }

    @FXML
    private void OnEditCustomerButtonClicked() {
        // TODO: implement method
    }

    @FXML
    private void OnAddCustomerButtonClicked() {
        // TODO: implement method
    }

    @FXML
    private void OnAddAppointmentButtonClicked() {
        // TODO: implement method
    }

    @FXML
    private void OnDeleteAppointmentButtonClicked() {
        // TODO: implement method
    }

    @FXML
    private void OnEditAppointmentButtonClicked() {
        // TODO: implement method
    }

    @FXML
    private void OnCurrentWeekRadioButtonClicked() {
        // TODO: implement method
    }

    @FXML
    private void OnCurrentMonthRadioButtonClicked() {
        // TODO: implement method
    }

    @FXML
    private void OnAllRadioButtonClicked() {
        // TODO: implement method
    }

    @FXML
    private void OnGoToReportsButtonClicked() {
        // TODO: implement method
    }

}
