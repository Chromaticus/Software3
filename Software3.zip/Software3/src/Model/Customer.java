package Model;

public class Customer {
}
